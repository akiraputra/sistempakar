<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-06-09 23:19:23 --> Severity: Notice  --> Use of undefined constant Pria - assumed 'Pria' C:\xampp\htdocs\sispakar\modules\main\views\main_register.php 73
ERROR - 2014-06-09 23:19:23 --> Severity: Notice  --> Use of undefined constant Wanita - assumed 'Wanita' C:\xampp\htdocs\sispakar\modules\main\views\main_register.php 74
ERROR - 2014-06-09 23:56:23 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 221
ERROR - 2014-06-09 23:58:49 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 220
