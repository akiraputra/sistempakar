<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-06-17 23:56:46 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '4'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-06-17 23:56:52 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '4'
AND `sp_relasi_gejala`.`kd_gejala` = 1
