<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class No_CMS_Model extends CMS_Model{}