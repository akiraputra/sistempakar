<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 1980-01-04 00:08:17 --> Severity: Notice  --> Undefined variable: riwayat_penyakit C:\xampp\htdocs\sispakar\modules\main\views\main_register.php 77
ERROR - 1980-01-04 00:18:09 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 472
ERROR - 1980-01-04 00:19:45 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 474
