<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-04-26 13:04:01 --> Severity: Notice  --> Undefined property: stdClass::$penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 157
