<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-11 16:12:05 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:05 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:07 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:07 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:07 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:07 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:10 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:10 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:10 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:10 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:10 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:10 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:11 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:11 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:11 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:11 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:11 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:11 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:13 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:13 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:13 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:13 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:21 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:21 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:22 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:22 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:12:23 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:12:23 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
ERROR - 2016-01-11 16:29:38 --> Severity: Warning  --> Missing argument 2 for Main::before_delete_user() C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 504
ERROR - 2016-01-11 16:29:38 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 510
