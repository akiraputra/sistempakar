<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-05-09 11:08:13 --> 404 Page Not Found --> 
ERROR - 2014-05-09 11:10:09 --> 404 Page Not Found --> layout/change_theme
