<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-08-25 12:28:19 --> 404 Page Not Found --> main/quicklick
ERROR - 2014-08-25 12:39:08 --> Query error: Table 'db_pakar.main_user' doesn't exist - Invalid query: SELECT user_id, user_name, real_name, email FROM main_user WHERE
                    (user_name = 'admin' OR email = 'admin') AND
                    password = '21232f297a57a5a743894a0e4a801fc3' AND
                    active = 1
ERROR - 2014-08-25 12:41:18 --> Query error: Table 'db_pakar.main_user' doesn't exist - Invalid query: SELECT user_id, user_name, real_name, email FROM main_user WHERE
                    (user_name = 'admin' OR email = 'admin') AND
                    password = '21232f297a57a5a743894a0e4a801fc3' AND
                    active = 1
ERROR - 2014-08-25 12:42:04 --> Query error: Table 'db_pakar.main_user' doesn't exist - Invalid query: SELECT user_id, user_name, real_name, email FROM main_user WHERE
                    (user_name = 'admin' OR email = 'admin') AND
                    password = '21232f297a57a5a743894a0e4a801fc3' AND
                    active = 1
ERROR - 2014-08-25 12:43:49 --> Query error: Table 'db_pakar.jlib_jsminexception' doesn't exist - Invalid query: SELECT user_id, user_name, real_name, email FROM JLIB_JSMinException WHERE
                    (user_name = 'admin' OR email = 'admin') AND
                    password = '21232f297a57a5a743894a0e4a801fc3' AND
                    active = 1
ERROR - 2014-08-25 12:47:21 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `user` (`user_name`, `password`, `email`, `real_name`, `alamat`, `riwayat_penyakit`) VALUES ('heru', 'a648ab9a3e32c5f3f6e9ddbd41c0530f', NULL, NULL, NULL, NULL)
ERROR - 2014-08-25 12:47:31 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `user` (`user_name`, `password`, `email`, `real_name`, `alamat`, `riwayat_penyakit`) VALUES ('heru', 'a648ab9a3e32c5f3f6e9ddbd41c0530f', NULL, NULL, NULL, NULL)
ERROR - 2014-08-25 12:47:41 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `user` (`user_name`, `password`, `email`, `real_name`, `alamat`, `riwayat_penyakit`) VALUES ('herup', '76d5ce30f71a372d6e1cd537d2b57fe2', NULL, NULL, NULL, NULL)
ERROR - 2014-08-25 12:49:00 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `user` (`user_name`, `password`, `email`, `real_name`, `alamat`, `riwayat_penyakit`) VALUES ('popopopopo1', '29ec439bc5849b70dce963156970de3b', NULL, NULL, NULL, NULL)
ERROR - 2014-08-25 12:49:36 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `user` (`user_name`, `password`, `email`, `real_name`, `alamat`, `riwayat_penyakit`) VALUES ('popopopopo1', '29ec439bc5849b70dce963156970de3b', NULL, NULL, NULL, NULL)
