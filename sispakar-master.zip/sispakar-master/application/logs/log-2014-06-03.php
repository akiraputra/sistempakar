<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-06-03 08:04:57 --> 404 Page Not Found --> layout/themes
ERROR - 2014-06-03 08:04:58 --> 404 Page Not Found --> layout/themes
ERROR - 2014-06-03 08:05:59 --> 404 Page Not Found --> layout/themes
ERROR - 2014-06-03 08:06:00 --> 404 Page Not Found --> layout/themes
