<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['cms_table_prefix'] = '';

$config['site_language'] = 'indonesian';
$config['max_menu_depth'] = '5';
$config['site_theme'] = 'cerulean';
$config['cms_google_analytic_property_id'] = '';
$config['site_favicon'] = '{{ base_url }}assets/nocms/images/No-CMS-favicon.png';
$config['site_logo'] = '{{ base_url }}assets/nocms/images/No-CMS-logo.png';
$config['site_name'] = 'Sistem Pakar';
$config['site_slogan'] = 'Diagnosa penyakit Kolitis Infeksi';
$config['site_footer'] = '<a href = "http://heruprambadi.com" target = "_blank">heruprambadi.com</a> © 2016';
$config['cms_signup_activation'] = 'FALSE';