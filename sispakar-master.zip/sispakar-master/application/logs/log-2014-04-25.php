<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-04-25 10:07:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-04-25 10:07:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-04-25 10:07:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-04-25 10:07:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:43 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:47 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:48 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:18:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:18:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:18:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:18:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:55 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:56 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 167
ERROR - 2014-04-25 10:18:58 --> Severity: Notice  --> Undefined variable: d C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 168
ERROR - 2014-04-25 10:39:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 145
ERROR - 2014-04-25 10:39:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 150
ERROR - 2014-04-25 10:39:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 155
ERROR - 2014-04-25 10:39:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 160
ERROR - 2014-04-25 10:39:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 164
ERROR - 2014-04-25 10:39:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 145
ERROR - 2014-04-25 10:39:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 150
ERROR - 2014-04-25 10:39:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 155
ERROR - 2014-04-25 10:39:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 160
ERROR - 2014-04-25 10:39:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 164
ERROR - 2014-04-25 10:39:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:39:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:39:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:39:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:39:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:39:06 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 145
ERROR - 2014-04-25 10:39:06 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 150
ERROR - 2014-04-25 10:39:06 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 155
ERROR - 2014-04-25 10:39:06 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 160
ERROR - 2014-04-25 10:39:06 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 164
ERROR - 2014-04-25 10:39:06 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 145
ERROR - 2014-04-25 10:39:06 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 150
ERROR - 2014-04-25 10:39:06 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 155
ERROR - 2014-04-25 10:39:06 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 160
ERROR - 2014-04-25 10:39:06 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 164
ERROR - 2014-04-25 10:39:10 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 145
ERROR - 2014-04-25 10:39:10 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 150
ERROR - 2014-04-25 10:39:10 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 155
ERROR - 2014-04-25 10:39:10 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 160
ERROR - 2014-04-25 10:39:10 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 145
ERROR - 2014-04-25 10:39:10 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 150
ERROR - 2014-04-25 10:39:10 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 155
ERROR - 2014-04-25 10:39:10 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 160
ERROR - 2014-04-25 10:39:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:39:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:39:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:39:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:39:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-04-25 10:39:13 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 145
ERROR - 2014-04-25 10:39:13 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 150
ERROR - 2014-04-25 10:39:13 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 155
ERROR - 2014-04-25 10:39:13 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 160
ERROR - 2014-04-25 10:39:13 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 145
ERROR - 2014-04-25 10:39:13 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 150
ERROR - 2014-04-25 10:39:13 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 155
ERROR - 2014-04-25 10:39:13 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 160
ERROR - 2014-04-25 10:51:57 --> Severity: Notice  --> Undefined property: CI_DB_pdo_mysql_driver::$count_kd_gejala C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 138
ERROR - 2014-04-25 10:51:57 --> Severity: Notice  --> Undefined property: CI_DB_pdo_mysql_driver::$count_kd_gejala C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 138
ERROR - 2014-04-25 10:52:00 --> Severity: Notice  --> Undefined property: CI_DB_pdo_mysql_driver::$count_kd_gejala C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 138
ERROR - 2014-04-25 10:52:00 --> Severity: Notice  --> Undefined property: CI_DB_pdo_mysql_driver::$count_kd_gejala C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 138
ERROR - 2014-04-25 11:03:05 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\sispakar\system\database\DB_query_builder.php 651
ERROR - 2014-04-25 11:03:06 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '4'
AND `sp_relasi_gejala`.`kd_gejala` = `Array`
ERROR - 2014-04-25 11:30:07 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 146
ERROR - 2014-04-25 11:30:07 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 146
ERROR - 2014-04-25 11:30:11 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 146
ERROR - 2014-04-25 11:30:11 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 146
ERROR - 2014-04-25 12:03:20 --> Query error: Unknown column 'sp_relasi_gejala.id_gejala' in 'on clause' - Invalid query: SELECT *, nm_gejala as s03df2e27
FROM `sp_relasi_gejala`
JOIN `sp_gejala` ON `sp_relasi_gejala`.`id_gejala` = `sp_gejala`.`id_gejala`
WHERE `id_analisa` = '4'
ORDER BY `sp_relasi_gejala`.`urutan`
