<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-06-10 00:01:48 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 221
ERROR - 2014-06-10 00:05:08 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 220
ERROR - 2014-06-10 00:15:05 --> Severity: Notice  --> Undefined variable: riwayat_penyakit C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 227
ERROR - 2014-06-10 00:15:41 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 219
