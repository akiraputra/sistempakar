<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-05-23 11:10:43 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '4'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-05-23 11:11:29 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '4'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:21:50 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:21:50 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:51 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:21:52 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:21:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:52 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:21:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:52 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:21:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:21:55 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:21:56 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:22:47 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:22:47 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:22:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:22:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:22:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Undefined property: CI::$cc_penyakit C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-23 15:22:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:24:00 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:24:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:24:00 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:24:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:24:00 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:24:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:24:00 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:24:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:24:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:24:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:24:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:24:02 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:24:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:24:02 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:24:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:24:02 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:24:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:24:02 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:24:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 176
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Undefined variable: cc_penyakit C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:24:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 182
ERROR - 2014-05-23 15:25:26 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:26 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:26 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:26 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:25:26 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:26 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:26 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:26 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:26 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:27 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:27 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:27 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:25:27 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:27 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:27 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:27 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:27 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:28 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:28 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:28 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:28 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:28 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:25:28 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:29 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:29 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:30 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:30 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:25:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:25:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:25:36 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:36 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:36 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:36 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:25:36 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:36 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:36 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:36 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:36 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:38 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:38 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:38 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:25:38 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:38 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:38 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:38 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:38 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:39 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:39 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:39 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:39 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:39 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:25:39 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:40 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:40 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:40 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:40 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:25:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:42 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:25:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:09 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:10 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:10 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:10 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:10 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:27:10 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:10 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:10 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:10 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:10 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:13 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:14 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:14 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:14 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:14 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:14 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:14 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:14 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:14 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:27:14 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:15 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:15 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:15 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:15 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:18 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:18 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:18 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:18 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:18 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:27:18 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:19 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:19 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:19 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:19 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:19 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:19 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:20 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:20 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:20 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:20 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:20 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:20 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:23 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:23 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:27:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:27:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:27:26 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:26 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:26 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:26 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:26 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:27:26 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:26 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:26 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:26 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:27 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:29 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:29 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:30 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:30 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:30 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:27:30 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:30 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:30 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:30 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:30 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:34 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:34 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:34 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:34 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:34 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:27:34 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:34 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:35 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:35 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:35 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:27:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:43 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:43 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:43 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:43 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:43 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:33:43 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:43 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:44 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:44 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:45 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:45 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:45 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:45 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:46 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:33:46 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:46 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:46 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:46 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:47 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:47 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:48 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:48 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:48 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:33:48 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:48 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:48 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:48 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:33:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:33:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:33:54 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:54 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:54 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:54 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:54 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:33:54 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:54 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:54 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:54 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:56 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:56 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:56 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:33:56 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:56 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:56 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:56 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:57 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:57 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:57 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:57 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:57 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 173
ERROR - 2014-05-23 15:33:57 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:57 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:57 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:57 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 173 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:33:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:28 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:28 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:28 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:29 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:29 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:29 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:30 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:30 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:30 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:31 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:36:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:36:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:36:36 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:36 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:36 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:36 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:36 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:36:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:38 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:38 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:38 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:38 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:38 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:36:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:40 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:40 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:40 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:40 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:36:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:15 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:15 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:15 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:15 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:15 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:37:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:17 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:17 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:17 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:17 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:17 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:37:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:18 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:18 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:19 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:19 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:37:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:37:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:37:23 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:23 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:24 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:24 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:25 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:25 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:25 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:27 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:27 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:27 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:53 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:40:53 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:40:59 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:40:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:00 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:02 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:04 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:41:06 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:41:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:41:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 15:41:25 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:41:25 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:41:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:26 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:27 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:31 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:41:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:36 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:41:36 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:41:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:37 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:38 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:41 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:41:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:42 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:42 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:42 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:42 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:42 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:43 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:43 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:43 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:43 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:43 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:44 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:44 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:44 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:44 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:44 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:46 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:46 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:41:46 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:41:46 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:46 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:46 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:51 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 15:41:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:41:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:52 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:45:52 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 15:45:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 15:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:01:48 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 157
ERROR - 2014-05-23 16:01:48 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 157
ERROR - 2014-05-23 16:01:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:51 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:54 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:01:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 161
ERROR - 2014-05-23 16:02:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:56 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:57 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:58 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:59 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:02:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:03:00 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:03:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:03:00 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:03:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:03:00 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:03:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:03:00 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:03:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:03:45 --> Severity: Warning  --> Missing argument 3 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 16:03:45 --> Severity: Warning  --> Missing argument 4 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 16:03:46 --> Severity: Warning  --> Missing argument 5 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 16:03:46 --> Severity: Warning  --> Missing argument 6 for Manage_Analisa::cc_penyakit() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 16:04:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:31 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 16:04:31 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 177
ERROR - 2014-05-23 16:04:31 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 180
ERROR - 2014-05-23 16:04:31 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 183
ERROR - 2014-05-23 16:04:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 177
ERROR - 2014-05-23 16:04:33 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 180
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 183
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:36 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 16:04:36 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 177
ERROR - 2014-05-23 16:04:36 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 180
ERROR - 2014-05-23 16:04:36 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 183
ERROR - 2014-05-23 16:04:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 16:04:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 16:04:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 16:04:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:43 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 16:04:43 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 177
ERROR - 2014-05-23 16:04:43 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 180
ERROR - 2014-05-23 16:04:43 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 183
ERROR - 2014-05-23 16:04:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 177
ERROR - 2014-05-23 16:04:45 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 180
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 183
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 16:04:48 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 174
ERROR - 2014-05-23 16:04:48 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 177
ERROR - 2014-05-23 16:04:48 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 180
ERROR - 2014-05-23 16:04:48 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 183
ERROR - 2014-05-23 18:14:47 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:14:47 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::kolitis(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 179 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 18:14:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:14:52 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:14:52 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::kolitis(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 179 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 18:14:52 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:14:53 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:05 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:05 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:06 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:06 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:06 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:06 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:08 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:15:09 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::kolitis(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 179 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:14 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:15:14 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::kolitis(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 179 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 18:15:14 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:16 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:16 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:16 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:16 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:22 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:15:22 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::kolitis(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 179 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 18:15:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:22 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:23 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:15:28 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::kolitis(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 179 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:28 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:30 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:32 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:15:32 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:15:32 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:15:32 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:15:32 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:15:32 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::kolitis(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 179 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 18:15:32 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:34 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:35 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:36 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:39 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:15:39 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::kolitis(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 179 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 18:15:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:39 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:40 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:42 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:42 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:42 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:42 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:43 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:43 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:43 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:43 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:43 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:44 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:44 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:44 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:44 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:44 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:15:45 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:15:45 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:15:45 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:15:45 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:15:45 --> Severity: Warning  --> Missing argument 2 for Manage_Analisa::kolitis(), called in C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php on line 179 and defined C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 136
ERROR - 2014-05-23 18:15:45 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:45 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:46 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:46 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:46 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:46 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:47 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:48 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:50 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:31 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:16:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:36 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:16:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:38 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:16:38 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:16:38 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:16:38 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:16:38 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:16:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:44 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:47 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:16:47 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:16:47 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:16:47 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:16:47 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:16:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:16:52 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:16:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:16:54 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:16:55 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:16:55 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:16:55 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:16:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 18:16:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 18:16:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 18:17:00 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:17:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:04 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:17:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:07 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:17:07 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:17:07 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:17:07 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:17:07 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:17:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:12 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:17:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:15 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:17:15 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:17:15 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:17:15 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:17:15 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:17:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:17:20 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:17:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:17:22 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:17:23 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:17:23 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:17:23 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:18:45 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:18:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:18:51 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:18:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:53 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:18:54 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:18:54 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:18:54 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:18:54 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:18:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:19:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:19:12 --> Severity: Notice  --> Use of undefined constant k1 - assumed 'k1' C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:19:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:19:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 140
ERROR - 2014-05-23 18:20:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:20:37 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:20:37 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:20:37 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:20:37 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:20:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:20:40 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:20:40 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:20:41 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:20:41 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:20:44 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:20:44 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:20:44 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:20:44 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:20:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 18:20:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 18:20:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sispakar\system\core\Exceptions.php:186) C:\xampp\htdocs\sispakar\system\libraries\Session\drivers\Session_cookie.php 725
ERROR - 2014-05-23 18:20:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:20:50 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:20:50 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:20:51 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:20:51 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:20:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:20:54 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:20:54 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:20:54 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:20:54 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
ERROR - 2014-05-23 18:20:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 166
ERROR - 2014-05-23 18:20:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 179
ERROR - 2014-05-23 18:20:57 --> Severity: Notice  --> Undefined variable: k1 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 200
ERROR - 2014-05-23 18:20:57 --> Severity: Notice  --> Undefined variable: k2 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-05-23 18:20:57 --> Severity: Notice  --> Undefined variable: k3 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 206
ERROR - 2014-05-23 18:20:57 --> Severity: Notice  --> Undefined variable: k4 C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 209
