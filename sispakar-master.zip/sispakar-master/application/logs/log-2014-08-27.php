<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-08-27 09:47:35 --> 404 Page Not Found --> pakar/bantuan
ERROR - 2014-08-27 09:55:27 --> 404 Page Not Found --> bantuan/index
ERROR - 2014-08-27 09:55:50 --> 404 Page Not Found --> bantuan/index
ERROR - 2014-08-27 09:56:19 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\sispakar\modules\pakar\controllers\bantuan.php 4
ERROR - 2014-08-27 09:56:52 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\sispakar\modules\pakar\controllers\bantuan.php 4
ERROR - 2014-08-27 10:16:26 --> 404 Page Not Found --> pakar/1.jpg
