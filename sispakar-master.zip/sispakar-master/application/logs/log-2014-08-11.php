<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-08-11 13:49:05 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\sispakar\modules\main\controllers\main.php 474
ERROR - 2014-08-11 13:57:34 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\sispakar\application\libraries\Grocery_CRUD.php 2346
ERROR - 2014-08-11 14:00:22 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:00:35 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:00:46 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:01:20 --> Query error: Unknown column 'user_name' in 'where clause' - Invalid query: SELECT *
FROM `sp_analisa`
WHERE `user_name` = 'heruprambadi'
ERROR - 2014-08-11 14:08:23 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:08:51 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:10:29 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 14
ERROR - 2014-08-11 14:10:29 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 14
ERROR - 2014-08-11 14:11:31 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 199
ERROR - 2014-08-11 14:11:31 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 14
ERROR - 2014-08-11 14:11:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 14
ERROR - 2014-08-11 14:19:01 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:19:43 --> Severity: Notice  --> Undefined variable: dt C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 14
ERROR - 2014-08-11 14:19:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 14
ERROR - 2014-08-11 14:20:43 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:20:49 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:21:05 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 20
ERROR - 2014-08-11 14:21:05 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 28
ERROR - 2014-08-11 14:21:05 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 37
ERROR - 2014-08-11 14:21:05 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 43
ERROR - 2014-08-11 14:21:05 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 20
ERROR - 2014-08-11 14:21:05 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 28
ERROR - 2014-08-11 14:21:05 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 37
ERROR - 2014-08-11 14:21:05 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 43
ERROR - 2014-08-11 14:24:26 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:24:32 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:24:45 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:25:00 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:25:03 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:29:20 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:30:40 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:31:15 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:31:20 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:31:29 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:31:33 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:31:47 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:32:07 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:32:18 --> 404 Page Not Found --> 
ERROR - 2014-08-11 14:32:24 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:32:32 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:33:01 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:33:04 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:33:05 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:33:07 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:33:08 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:33:40 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:33:46 --> 404 Page Not Found --> 
ERROR - 2014-08-11 14:34:08 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:35:38 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 20
ERROR - 2014-08-11 14:35:38 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 28
ERROR - 2014-08-11 14:35:38 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 37
ERROR - 2014-08-11 14:35:38 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 43
ERROR - 2014-08-11 14:35:38 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 20
ERROR - 2014-08-11 14:35:38 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 28
ERROR - 2014-08-11 14:35:38 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 37
ERROR - 2014-08-11 14:35:38 --> Severity: Notice  --> Undefined variable: penyakit C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 43
ERROR - 2014-08-11 14:37:13 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:37:20 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:37:38 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:37:40 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:38:30 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:38:53 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '11'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:40:12 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '4'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:40:57 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'field list' - Invalid query: SELECT *, count(sp_relasi_gejala.id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '4'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:41:42 --> Query error: Unknown column 'sp_relasi_gejala.id_analisa' in 'where clause' - Invalid query: SELECT *, count(sp_relasi_gejala.fk_id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`id_analisa` = '4'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 14:41:57 --> Query error: Unknown column 'sp_relasi_gejala.kd_gejala' in 'where clause' - Invalid query: SELECT *, count(sp_relasi_gejala.fk_id_analisa) count_id_analisa
FROM `sp_relasi_gejala`
WHERE `sp_relasi_gejala`.`fk_id_analisa` = '4'
AND `sp_relasi_gejala`.`kd_gejala` = 1
ERROR - 2014-08-11 15:19:40 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\sispakar\application\libraries\Grocery_CRUD.php 2346
ERROR - 2014-08-11 15:22:36 --> Severity: Runtime Notice  --> Declaration of Manage_Analisa::view() should be compatible with CMS_Controller::view($view_url, $data = NULL, $navigation_name = NULL, $config = NULL, $return_as_string = false) C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 207
ERROR - 2014-08-11 15:26:00 --> Severity: Runtime Notice  --> Declaration of Manage_Analisa::view() should be compatible with CMS_Controller::view($view_url, $data = NULL, $navigation_name = NULL, $config = NULL, $return_as_string = false) C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 207
ERROR - 2014-08-11 15:26:25 --> Severity: Runtime Notice  --> Declaration of Manage_Analisa::view() should be compatible with CMS_Controller::view($view_url, $data = NULL, $navigation_name = NULL, $config = NULL, $return_as_string = false) C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 211
ERROR - 2014-08-11 15:29:56 --> Severity: Runtime Notice  --> Declaration of Manage_Analisa::view() should be compatible with CMS_Controller::view($view_url, $data = NULL, $navigation_name = NULL, $config = NULL, $return_as_string = false) C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 212
ERROR - 2014-08-11 15:30:39 --> Severity: Runtime Notice  --> Declaration of Manage_Analisa::view() should be compatible with CMS_Controller::view($view_url, $data = NULL, $navigation_name = NULL, $config = NULL, $return_as_string = false) C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 293
ERROR - 2014-08-11 15:30:53 --> Severity: Runtime Notice  --> Declaration of Manage_Analisa::view() should be compatible with CMS_Controller::view($view_url, $data = NULL, $navigation_name = NULL, $config = NULL, $return_as_string = false) C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 293
ERROR - 2014-08-11 15:30:55 --> Severity: Runtime Notice  --> Declaration of Manage_Analisa::view() should be compatible with CMS_Controller::view($view_url, $data = NULL, $navigation_name = NULL, $config = NULL, $return_as_string = false) C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 293
ERROR - 2014-08-11 16:00:45 --> 404 Page Not Found --> manage_analisa/4
ERROR - 2014-08-11 16:01:13 --> Severity: Warning  --> Missing argument 1 for Manage_Analisa::lihat() C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 203
ERROR - 2014-08-11 16:01:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\sispakar\modules\pakar\controllers\manage_analisa.php 207
ERROR - 2014-08-11 16:06:28 --> Severity: Notice  --> Undefined property: stdClass::$full_name C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_personal.php 13
ERROR - 2014-08-11 16:06:59 --> Severity: Notice  --> Undefined property: stdClass::$real_name C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_personal.php 13
ERROR - 2014-08-11 16:09:24 --> Query error: Not unique table/alias: 'sp_analisa' - Invalid query: SELECT *
FROM `sp_analisa`
JOIN `sp_analisa` ON `username`.`sp_analisa`=`user_name`.`cms_user`
WHERE `id_analisa` = '11'
ERROR - 2014-08-11 16:10:25 --> Query error: Not unique table/alias: 'sp_analisa' - Invalid query: SELECT *
FROM `sp_analisa`
JOIN `sp_analisa` ON `sp_analisa`.`username`=`cms_user`.`user_name`
WHERE `id_analisa` = '11'
ERROR - 2014-08-11 16:10:27 --> Query error: Not unique table/alias: 'sp_analisa' - Invalid query: SELECT *
FROM `sp_analisa`
JOIN `sp_analisa` ON `sp_analisa`.`username`=`cms_user`.`user_name`
WHERE `id_analisa` = '11'
ERROR - 2014-08-11 16:11:29 --> Query error: Unknown column 'cms_user.user_name' in 'on clause' - Invalid query: SELECT *
FROM `sp_analisa`
JOIN `main_user` ON `sp_analisa`.`username`=`cms_user`.`user_name`
WHERE `id_analisa` = '11'
ERROR - 2014-08-11 16:11:49 --> Query error: Unknown column 'username.sp_analisa' in 'on clause' - Invalid query: SELECT *
FROM `sp_analisa`
JOIN `main_user` ON `username`.`sp_analisa`=`user_name`.`main_user`
WHERE `id_analisa` = '11'
ERROR - 2014-08-11 16:11:50 --> Query error: Unknown column 'username.sp_analisa' in 'on clause' - Invalid query: SELECT *
FROM `sp_analisa`
JOIN `main_user` ON `username`.`sp_analisa`=`user_name`.`main_user`
WHERE `id_analisa` = '11'
ERROR - 2014-08-11 16:15:34 --> 404 Page Not Found --> 
ERROR - 2014-08-11 16:16:33 --> 404 Page Not Found --> pakar/assets
ERROR - 2014-08-11 16:16:33 --> 404 Page Not Found --> pakar/assets
ERROR - 2014-08-11 16:17:08 --> 404 Page Not Found --> pakar/assets
ERROR - 2014-08-11 16:17:09 --> 404 Page Not Found --> pakar/assets
ERROR - 2014-08-11 16:17:13 --> 404 Page Not Found --> pakar/assets
ERROR - 2014-08-11 16:17:28 --> 404 Page Not Found --> 
ERROR - 2014-08-11 16:17:29 --> 404 Page Not Found --> 
ERROR - 2014-08-11 16:17:34 --> 404 Page Not Found --> 
ERROR - 2014-08-11 21:16:01 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\sispakar\application\libraries\Grocery_CRUD.php 2346
ERROR - 2014-08-11 21:26:31 --> Severity: Notice  --> Undefined property: stdClass::$address C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_personal.php 29
ERROR - 2014-08-11 21:30:11 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\sispakar\application\libraries\Grocery_CRUD.php 2346
