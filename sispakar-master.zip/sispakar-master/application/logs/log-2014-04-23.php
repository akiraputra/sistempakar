<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-04-23 08:20:12 --> The session cookie data did not match what was expected.
ERROR - 2014-04-23 08:20:13 --> The session cookie data did not match what was expected.
ERROR - 2014-04-23 08:56:23 --> The session cookie data did not match what was expected.
