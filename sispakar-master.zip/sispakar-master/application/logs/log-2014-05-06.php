<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-05-06 11:04:15 --> The session cookie data did not match what was expected.
