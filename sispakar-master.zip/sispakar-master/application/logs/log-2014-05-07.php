<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-05-07 12:41:56 --> Severity: Notice  --> Undefined property: CI::$index C:\xampp\htdocs\sispakar\application\third_party\MX\Controller.php 58
ERROR - 2014-05-07 12:48:07 --> Query error: Unknown column 'no_telp' in 'field list' - Invalid query: UPDATE `main_user` SET `user_name` = 'puatkanani', `email` = 'sdfs@sdf.sdf', `password` = 'e10adc3949ba59abbe56e057f20f883e', `real_name` = 'Puat Kanani', `active` = '1', `alamat` = NULL, `sex` = NULL, `pekerjaan` = NULL, `no_telp` = '', `tanggal` = NULL, `riwayat_penyakit` = NULL
WHERE `user_id` = '2'
ERROR - 2014-05-07 12:48:17 --> Query error: Unknown column 'no_telp' in 'field list' - Invalid query: UPDATE `main_user` SET `user_name` = 'puatkanani', `email` = 'sdfs@sdf.sdf', `password` = 'e10adc3949ba59abbe56e057f20f883e', `real_name` = 'Puat Kanani', `active` = '1', `alamat` = NULL, `sex` = NULL, `pekerjaan` = NULL, `no_telp` = '', `tanggal` = NULL, `riwayat_penyakit` = NULL
WHERE `user_id` = '2'
ERROR - 2014-05-07 12:48:50 --> Query error: Unknown column 'no_telp' in 'field list' - Invalid query: UPDATE `main_user` SET `user_name` = 'puatkanani', `email` = 'sdfs@sdf.sdf', `password` = 'e10adc3949ba59abbe56e057f20f883e', `real_name` = 'Puat Kanani', `active` = '1', `alamat` = NULL, `sex` = NULL, `pekerjaan` = NULL, `no_telp` = '', `tanggal` = NULL, `riwayat_penyakit` = NULL
WHERE `user_id` = '2'
ERROR - 2014-05-07 12:48:50 --> Query error: Unknown column 'no_telp' in 'field list' - Invalid query: UPDATE `main_user` SET `user_name` = 'puatkanani', `email` = 'sdfs@sdf.sdf', `password` = 'e10adc3949ba59abbe56e057f20f883e', `real_name` = 'Puat Kanani', `active` = '1', `alamat` = NULL, `sex` = NULL, `pekerjaan` = NULL, `no_telp` = '', `tanggal` = NULL, `riwayat_penyakit` = NULL
WHERE `user_id` = '2'
ERROR - 2014-05-07 12:48:50 --> Query error: Unknown column 'no_telp' in 'field list' - Invalid query: UPDATE `main_user` SET `user_name` = 'puatkanani', `email` = 'sdfs@sdf.sdf', `password` = 'e10adc3949ba59abbe56e057f20f883e', `real_name` = 'Puat Kanani', `active` = '1', `alamat` = NULL, `sex` = NULL, `pekerjaan` = NULL, `no_telp` = '', `tanggal` = NULL, `riwayat_penyakit` = NULL
WHERE `user_id` = '2'
