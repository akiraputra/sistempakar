<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-05-01 21:20:18 --> 404 Page Not Found --> 
ERROR - 2014-05-01 21:31:39 --> 404 Page Not Found --> 
ERROR - 2014-05-01 21:33:03 --> 404 Page Not Found --> 
ERROR - 2014-05-01 21:33:14 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 4
ERROR - 2014-05-01 21:33:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 4
ERROR - 2014-05-01 21:33:34 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 3
ERROR - 2014-05-01 21:33:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 3
ERROR - 2014-05-01 21:49:18 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\sispakar\modules\pakar\views\manage_analisa_dl.php 5
